#!/bin/sh
echo -ne '\033c\033]0;Thought Spores\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Thought Spores.x86_64" "$@"
